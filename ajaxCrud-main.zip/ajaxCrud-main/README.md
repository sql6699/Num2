# ajaxCrud
网站地址：   http://www.liurui13.cn:8080/login.html  
(请用管理员账户登录  用户名：admin  密码：1234 注册的新用户没有权限查看用户管理界面)
