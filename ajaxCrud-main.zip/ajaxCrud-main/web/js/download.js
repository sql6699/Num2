function downloadDoc(path) {
    window.location.href='servlet/download.do?relativePath='+path;
}